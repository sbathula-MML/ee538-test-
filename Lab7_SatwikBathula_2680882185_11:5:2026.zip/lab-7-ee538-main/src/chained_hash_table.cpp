#include "chained_hash_table.hpp"

namespace lab {

std::size_t ChainedHashTable::bucket_index(const std::string& key) const {
    std::size_t hash = 0;
    for (unsigned char byte : key) {
        hash = (31 * hash + byte) % kBucketCount;
    }
    return hash;
}

void ChainedHashTable::put(const std::string& key, int value) {
    auto& chain = buckets_[bucket_index(key)];
    for (auto& entry : chain) {
        if (entry.key == key) {
            entry.value = value;
            return;
        }
    }

    chain.push_back(Entry{key, value});
    ++size_;
}

std::optional<int> ChainedHashTable::find(const std::string& key) const {
    const auto& chain = buckets_[bucket_index(key)];
    for (const auto& entry : chain) {
        if (entry.key == key) {
            return entry.value;
        }
    }
    return std::nullopt;
}

bool ChainedHashTable::erase(const std::string& key) {
    auto& chain = buckets_[bucket_index(key)];
    for (auto it = chain.begin(); it != chain.end(); ++it) {
        if (it->key == key) {
            chain.erase(it);
            --size_;
            return true;
        }
    }
    return false;
}

}  // namespace lab
