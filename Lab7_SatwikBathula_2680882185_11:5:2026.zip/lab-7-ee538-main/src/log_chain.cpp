#include "log_chain.hpp"

namespace lab {

void LogChain::append(const std::string& record) {
    const auto digest = crypto::hash_record(final_digest(), record);
    entries_.push_back(LogEntry{record, digest});
}

crypto::Digest LogChain::final_digest() const {
    if (entries_.empty()) {
        return initial_digest();
    }
    return entries_.back().digest;
}

bool LogChain::verify(const std::vector<LogEntry>& entries,
                      const crypto::Digest& trusted_final) {
    auto previous = initial_digest();
    for (const auto& entry : entries) {
        const auto expected = crypto::hash_record(previous, entry.record);
        if (entry.digest != expected) {
            return false;
        }
        previous = expected;
    }
    return previous == trusted_final;
}

}  // namespace lab
