# EE538 — Heaps and Hashing Lab

- Name: Satwik Bathula
- Student ID: 2680882185
- Compiler and version: g++ (Ubuntu 11.4.0-1ubuntu1~22.04.3) 11.4.0
- Extra credit attempted: Yes

Read [Assignment.html](Assignment.html) for all requirements and commands.
Complete this file with brief answers and your test results.

## Implementation

1. Heap: In what order does your bottom-up build repair the heap?
   Why is the total cost O(n), rather than O(n log n)?

   Answer: The build starts with the last internal node (index `n / 2 - 1`) and calls `sift_down` on each parent in reverse order, ending at the root. Leaves already satisfy the heap property. Most nodes are near the leaves, so the total work summed by subtree height is O(n), not O(n log n).

2. Hash table: How does a collision differ from a duplicate key?
   How do `put` and `erase` maintain the correct `size_`?

   Answer: A collision occurs when different keys map to the same bucket; each remains a distinct entry in that bucket's list. A duplicate key matches an existing key and updates its value without changing `size_`. `put` increments `size_` only when it inserts a new key, while `erase` decrements it only after successfully deleting a key.

## Testing

| Provided checks | Passed / total |
|---|---|
| Required heap and hash-table tests | 11 / 11 |
| Provided SHA-256 helper tests | 4 / 4 |
| Optional log-chain tests | 6 / 6 |

Add one of your own cases for each required component. Include the commands
entered in its program, or the operations in a separate C++ API test.

| Your test | Commands / operations | Expected result | Actual result |
|---|---|---|---|
| Heap | `BUILD 6 4 -3 4 0 -3 9`<br>`TOP`<br>`POP`<br>`PUSH -5`<br>`TOP`<br>`POP`<br>`POP`<br>`SIZE`<br>`QUIT` | `-3`, `-3`, `-5`, `-5`, `-3`, `4` | `-3`, `-3`, `-5`, `-5`, `-3`, `4` (pass) |
| Hash table | `PUT a 10`<br>`PUT h 20`<br>`PUT o 30`<br>`PUT h -1`<br>`SIZE`<br>`FIND a`<br>`FIND h`<br>`ERASE a`<br>`FIND o`<br>`ERASE a`<br>`PUT "" 77`<br>`BUCKET ""`<br>`SIZE`<br>`FIND ""`<br>`QUIT` | `3`, `10`, `-1`, `true`, `30`, `false`, `0`, `3`, `77` | `3`, `10`, `-1`, `true`, `30`, `false`, `0`, `3`, `77` (pass) |

## Extra credit (if attempted)

Why must the trusted final digest be kept separately from editable history?
What happens if an attacker changes a record and recomputes later digests?

Answer: The trusted final digest must be stored independently so that edits to the history cannot also replace the reference used to verify it. An attacker can modify a record and recompute all following digests to make the edited chain internally consistent, but its final digest will differ from the original trusted digest. The original anchor therefore detects the change.

## Known issues and references

Known issues: None observed in the supplied tests or the two additional tests.

References: Provided `Assignment.html`, supplied headers and tests, and C++17 standard-library documentation.
